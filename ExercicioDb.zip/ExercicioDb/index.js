import {selectConsumo, insertConsumo, updateConsumo, deleteConsumo} from "./queries.js"


insertConsumo()
selectConsumo()