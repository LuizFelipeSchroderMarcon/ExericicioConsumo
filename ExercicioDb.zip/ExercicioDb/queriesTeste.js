import read from 'readline-sync'


// let valorVelho = read.question('Informe qual o valor que deseja substituir: ');
// let valorNovo = read.question('Informe qual o valor que deseja inserir novo: ');





