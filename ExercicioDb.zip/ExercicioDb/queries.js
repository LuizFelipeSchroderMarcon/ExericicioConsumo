import read from 'readline-sync'
import connect from './db.js'


export async function selectConsumo(){
    const sql  = "SELECT * FROM CONSUMO;"
    const conn = await connect()
    const consumo = await conn.query(sql,[])
    console.log(consumo[0])
}

export async function insertConsumo(){
    let numMedidor = parseInt(read.question('Informe o numero do medidor de consumo: '));
    let nomeResponsavel = read.question('Informe o nome do responsavel: ');
    let consumo = parseFloat(read.question('Informe quantos litros foram consumidos: '))
    let preco;
    if(consumo <= 20){
        preco = consumo * 1.60;
    }
    else if(consumo > 20 && consumo <= 50){
        preco = consumo * 2.80;
    }
    else{
        preco = consumo * 4.20;
    }
    
    if(preco < 100.00){
        preco -= preco * 0.05;
    }
    else if(preco > 200.00){
        preco += preco * 0.10;
    }
    
    console.log(`Numero do medidor: ${numMedidor}, Nome do Responsavel: ${nomeResponsavel}, Valor Consumido: ${preco}`);
    
    
    const sql = `INSERT INTO consumo(num_medidor, nome_responsavel, preco) VALUES (${numMedidor},'${nomeResponsavel}',${preco});`
    const conn = await connect()
    console.log("Insercao efetuada")
    return await conn.query(sql)
}

export async function updateConsumo(){
    let valorVelho = read.question('Informe qual o valor que deseja substituir: ');
    let valorNovo = read.question('Informe qual o valor que deseja inserir novo: ');

    const sql = `UPDATE consumo SET nome_responsavel = '${valorNovo}' WHERE nome_responsavel LIKE '${valorVelho}';`
    const conn = await connect()
    console.log("Atualizacao efetuada")
    return await conn.query(sql)
}


export async function deleteConsumo(){
    let valorDeletado = read.question('Informe o que voce deseja deletar: ')

    const sql = `DELETE FROM consumo WHERE nome_responsavel LIKE '${valorDeletado}';`
    const conn = await connect()
    console.log("Deletagem efetuada")
    return await conn.query(sql)
}

//DELETE FROM consumo(nome tabela) where nome_responsavel LIKE 'pai'
